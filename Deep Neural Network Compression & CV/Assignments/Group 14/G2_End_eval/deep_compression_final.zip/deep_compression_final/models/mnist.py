"""
models/mnist.py
───────────────
Simple 4-layer MLP for MNIST classification.
Uses modified_linear so pruning and quantisation work transparently.
"""

from torch import nn
from compression.linear import modified_linear


class mnist_model(nn.Module):

    def __init__(self):
        super().__init__()
        self.flatten = nn.Flatten()
        self.classifier = nn.Sequential(
            modified_linear(28 * 28, 256), nn.ReLU(),
            modified_linear(256, 512),     nn.ReLU(),
            modified_linear(512, 256),     nn.ReLU(),
            modified_linear(256, 10),
        )

    def forward(self, x):
        x = self.flatten(x)
        return self.classifier(x)

    def prune(self, threshold: float):
        for m in self.modules():
            if isinstance(m, modified_linear):
                m.prune(threshold)

    def quantize(self, k: int):
        for m in self.modules():
            if isinstance(m, modified_linear):
                m.quantize(k)
