"""
models/cifar.py
───────────────
SmallCIFARNet — compact CNN for CIFAR-10 using the project's custom
modified_linear and modified_conv2d wrappers, which support pruning
and KMeans quantisation transparently.

Architecture  (input: 3 × 32 × 32)
────────────────────────────────────
Block 1:  Conv(3→32)  BN ReLU · Conv(32→32)  BN ReLU · Pool · Drop(0.25)
Block 2:  Conv(32→64) BN ReLU · Conv(64→64)  BN ReLU · Pool · Drop(0.25)
Block 3:  Conv(64→128) BN ReLU · Pool
Classifier: FC(2048→256) ReLU Drop(0.5) FC(256→10)

Parameters: ~2.1 M
Expected accuracy: ~79–82 % on CIFAR-10 after 20 epochs
"""

import torch
import torch.nn as nn
from compression.linear import modified_linear
from compression.conv2d import modified_conv2d


class SmallCIFARNet(nn.Module):

    def __init__(self, num_classes: int = 10, dropout: float = 0.25):
        super().__init__()

        self.features = nn.Sequential(
            # ── Block 1 ──────────────────────────────────────────────────────
            modified_conv2d(3,  32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(inplace=True),
            modified_conv2d(32, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Dropout2d(dropout),

            # ── Block 2 ──────────────────────────────────────────────────────
            modified_conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            modified_conv2d(64, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Dropout2d(dropout),

            # ── Block 3 ──────────────────────────────────────────────────────
            modified_conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
        )

        self.flatten = nn.Flatten()   # → 128 × 4 × 4 = 2048

        self.classifier = nn.Sequential(
            modified_linear(128 * 4 * 4, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            modified_linear(256, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = self.flatten(x)
        return self.classifier(x)

    def prune(self, threshold: float):
        """Apply pruning threshold to every modified_* layer."""
        for m in self.modules():
            if isinstance(m, (modified_conv2d, modified_linear)):
                m.prune(threshold)

    def quantize(self, k: int):
        """Apply KMeans quantisation to every modified_* layer."""
        for m in self.modules():
            if isinstance(m, (modified_conv2d, modified_linear)):
                m.quantize(k)
