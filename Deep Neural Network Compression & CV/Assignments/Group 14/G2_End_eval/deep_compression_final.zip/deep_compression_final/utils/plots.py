"""
utils/plots.py
──────────────
Visualisation for the compression benchmark.

  plot_model_comparison(results, save_dir)
  plot_accuracy_vs_sparsity(sparsities, accuracies, labels, save_dir)
  plot_dense_vs_sparse(results, save_dir)
  plot_multi_ratio(curve, baseline_acc, save_dir)
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

_C = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B2", "#937860"]


def _bar(ax, labels, values, title, ylabel, colors, fmt="{:.2f}"):
    x    = np.arange(len(labels))
    bars = ax.bar(x, values, color=colors[:len(labels)],
                  width=0.55, edgecolor="white", linewidth=0.7)
    ax.set_title(title, fontsize=11, fontweight="bold", pad=7)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=18, ha="right", fontsize=8)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", ls="--", alpha=0.35, lw=0.8)
    for bar, v in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height()*1.015,
                fmt.format(v), ha="center", va="bottom", fontsize=8)


def plot_model_comparison(results: list, save_dir: str = "results") -> str:
    """4-panel bar chart: Accuracy / Size / Latency / RAM."""
    os.makedirs(save_dir, exist_ok=True)
    labels = [r["label"]      for r in results]
    acc    = [r["accuracy"]   for r in results]
    sizes  = [r["size_mb"]    for r in results]
    lat    = [r["latency_ms"] for r in results]
    ram    = [r["ram_mb"]     for r in results]

    fig, axes = plt.subplots(2, 2, figsize=(13, 8))
    fig.suptitle("DNN Compression — CIFAR-10 Comparison",
                 fontsize=14, fontweight="bold", y=1.01)

    _bar(axes[0,0], labels, acc,   "Test Accuracy",           "Accuracy (%)",  _C, "{:.2f}%")
    _bar(axes[0,1], labels, sizes, "Model Size (Dense .pth)", "Size (MB)",     _C, "{:.2f}")
    _bar(axes[1,0], labels, lat,   "Inference Latency",       "ms / sample",   _C, "{:.3f}")
    _bar(axes[1,1], labels, ram,   "Peak RAM (CPU)",          "RAM (MB)",      _C, "{:.2f}")

    if len(results) >= 2:
        best  = min(results[1:], key=lambda r: r["size_mb"])
        ratio = results[0]["size_mb"] / best["size_mb"]
        idx   = results.index(best)
        if ratio > 1.1:
            axes[0,1].annotate(
                f"{ratio:.1f}× smaller",
                xy=(idx, best["size_mb"]),
                xytext=(max(0, idx-1.3), results[0]["size_mb"]*0.60),
                arrowprops=dict(arrowstyle="->", lw=1.2),
                fontsize=8.5,
            )

    plt.tight_layout()
    path = os.path.join(save_dir, "model_comparison.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [plot] model_comparison      → {path}")
    return path


def plot_accuracy_vs_sparsity(
    sparsities: list, accuracies: list, labels: list,
    save_dir: str = "results",
) -> str:
    """Line + scatter: accuracy vs pruning ratio."""
    os.makedirs(save_dir, exist_ok=True)
    xs = [s * 100 for s in sparsities]

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(xs, accuracies, marker="o", lw=2.2, ms=9,
            color=_C[0], mec="white", mew=1.5, zorder=3)
    ax.axhline(accuracies[0], color="grey", lw=1.2, ls="--", alpha=0.6,
               label=f"Baseline  {accuracies[0]:.2f}%")
    ax.fill_between(xs, accuracies[0], accuracies,
                    where=[a < accuracies[0] for a in accuracies],
                    alpha=0.12, color=_C[3], label="Accuracy drop")
    for x, y, lbl in zip(xs, accuracies, labels):
        ax.annotate(f"{lbl}\n{y:.2f}%", xy=(x, y),
                    xytext=(x+1.5, y-0.55), fontsize=8, color="#333")
    ax.set_xlabel("Pruning Ratio (%)", fontsize=10)
    ax.set_ylabel("Test Accuracy (%)", fontsize=10)
    ax.set_title("Accuracy vs Pruning Ratio (after fine-tuning)",
                 fontsize=13, fontweight="bold")
    ax.legend(fontsize=9)
    ax.spines[["top","right"]].set_visible(False)
    ax.grid(ls="--", alpha=0.35, lw=0.8)
    ax.set_xlim(-3, max(xs)+12)
    ax.set_ylim(min(accuracies)-2, accuracies[0]+1.5)

    plt.tight_layout()
    path = os.path.join(save_dir, "accuracy_vs_sparsity.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [plot] accuracy_vs_sparsity  → {path}")
    return path


def plot_dense_vs_sparse(results: list, save_dir: str = "results") -> str:
    """Grouped bars: dense .pth vs CSR sparse .npz per variant."""
    os.makedirs(save_dir, exist_ok=True)
    labels = [r["label"]  for r in results]
    dense  = [r["size_mb"] for r in results]
    sparse = [r.get("sparse_mb") or r["size_mb"] for r in results]
    x, w   = np.arange(len(labels)), 0.35

    fig, ax = plt.subplots(figsize=(10, 5.5))
    b1 = ax.bar(x-w/2, dense,  w, label="Dense  (.pth)",     color=_C[0], edgecolor="white")
    b2 = ax.bar(x+w/2, sparse, w, label="Sparse (CSR .npz)", color=_C[1], edgecolor="white")
    for bar, v in zip(list(b1)+list(b2), dense+sparse):
        ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.05,
                f"{v:.2f}", ha="center", va="bottom", fontsize=8)

    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=16, ha="right", fontsize=8.5)
    ax.set_ylabel("File Size (MB)", fontsize=10)
    ax.set_title("Dense vs CSR Sparse Storage Size", fontsize=13, fontweight="bold")
    ax.legend(fontsize=10)
    ax.spines[["top","right"]].set_visible(False)
    ax.grid(axis="y", ls="--", alpha=0.35, lw=0.8)

    plt.tight_layout()
    path = os.path.join(save_dir, "dense_vs_sparse.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [plot] dense_vs_sparse       → {path}")
    return path


def plot_multi_ratio(
    curve: list, baseline_acc: float,
    save_dir: str = "results",
) -> str:
    """3-line chart: post-prune / post-FT / post-PTQ across ratios."""
    os.makedirs(save_dir, exist_ok=True)
    ratios  = [r["ratio"]*100          for r in curve]
    pre_ft  = [r["acc_after_prune"]    for r in curve]
    post_ft = [r["acc_after_finetune"] for r in curve]
    ptq     = [r["acc_ptq"]            for r in curve]

    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    ax.axhline(baseline_acc, color="grey", lw=1.5, ls="--", alpha=0.7,
               label=f"Baseline ({baseline_acc:.2f}%)")
    ax.plot(ratios, pre_ft,  marker="s", lw=2, ms=7.5, color=_C[3],
            label="After pruning (no fine-tune)")
    ax.plot(ratios, post_ft, marker="o", lw=2.2, ms=9,  color=_C[1],
            label="After fine-tuning")
    ax.plot(ratios, ptq,     marker="^", lw=2, ms=8,   color=_C[2],
            label="After PTQ int8")
    for x, y in zip(ratios, post_ft):
        ax.annotate(f"{y:.1f}%", xy=(x,y), xytext=(x+0.5, y+0.25), fontsize=8.5)

    ax.set_xlabel("Pruning Ratio (%)", fontsize=10)
    ax.set_ylabel("Test Accuracy (%)", fontsize=10)
    ax.set_title("Accuracy at Multiple Pruning Ratios", fontsize=13, fontweight="bold")
    ax.legend(fontsize=9, loc="lower left")
    ax.spines[["top","right"]].set_visible(False)
    ax.grid(ls="--", alpha=0.35, lw=0.8)
    all_acc = pre_ft+post_ft+ptq+[baseline_acc]
    ax.set_ylim(min(all_acc)-3, max(all_acc)+2)
    ax.set_xlim(min(ratios)-3, max(ratios)+5)

    plt.tight_layout()
    path = os.path.join(save_dir, "multi_ratio.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  [plot] multi_ratio           → {path}")
    return path
