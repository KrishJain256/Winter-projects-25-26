"""
utils/metrics.py
────────────────
Automatic metric measurement utilities.

  measure_accuracy(model, loader, device)     → float   (%)
  measure_model_size(model)                   → float   (MB)
  measure_latency(model, loader, device)      → float   (ms/sample)
  measure_ram(model, loader, device)          → float   (MB peak)
  full_metrics(model, loader, device, ...)    → dict
  print_table(results)                        → None
"""

import os
import time
import tempfile
import tracemalloc

import torch
import torch.nn as nn


def measure_accuracy(model: nn.Module, loader, device) -> float:
    model.eval()
    correct = total = 0
    with torch.no_grad():
        for x, y in loader:
            x, y   = x.to(device), y.to(device)
            correct += (model(x).argmax(1) == y).sum().item()
            total   += y.size(0)
    return 100.0 * correct / total


def measure_model_size(model: nn.Module) -> float:
    """Disk size of state_dict (MB)."""
    fd, tmp = tempfile.mkstemp(suffix=".pth")
    os.close(fd)
    torch.save(model.state_dict(), tmp)
    sz = os.path.getsize(tmp) / 1024 ** 2
    os.remove(tmp)
    return round(sz, 3)


def measure_latency(
    model: nn.Module,
    loader,
    device,
    n_batches: int = 50,
    warmup:    int = 5,
) -> float:
    """Average ms per sample over `n_batches` batches after `warmup` warmup."""
    model.eval()
    t_total = n_total = counted = 0
    with torch.no_grad():
        for i, (x, _) in enumerate(loader):
            x = x.to(device)
            if device.type == "cuda":
                torch.cuda.synchronize()
            t0 = time.perf_counter()
            model(x)
            if device.type == "cuda":
                torch.cuda.synchronize()
            if i >= warmup:
                t_total += time.perf_counter() - t0
                n_total += x.size(0)
                counted += 1
            if counted >= n_batches:
                break
    return round(1000 * t_total / n_total, 4) if n_total else float("nan")


def measure_ram(
    model: nn.Module,
    loader,
    device,
    n_batches: int = 10,
) -> float:
    """Peak CPython heap during inference (MB) via tracemalloc."""
    model.eval()
    tracemalloc.start()
    with torch.no_grad():
        for i, (x, _) in enumerate(loader):
            model(x.to(device))
            if i + 1 >= n_batches:
                break
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return round(peak / 1024 ** 2, 3)


def full_metrics(
    model:     nn.Module,
    loader,
    device,
    label:     str   = "model",
    sparse_mb: float = None,
) -> dict:
    """Run all four measurements and return a single result dict."""
    print(f"\n  ── Measuring '{label}' ──")
    acc = measure_accuracy(model, loader, device)
    sz  = measure_model_size(model)
    lat = measure_latency(model, loader, device)
    ram = measure_ram(model, loader, device)

    sp_line = f"  sparse (CSR) : {sparse_mb:.3f} MB\n" if sparse_mb else ""
    print(
        f"  accuracy     : {acc:.2f}%\n"
        f"  dense size   : {sz:.3f} MB\n"
        f"{sp_line}"
        f"  latency      : {lat:.4f} ms/sample\n"
        f"  peak RAM     : {ram:.3f} MB"
    )
    return {
        "label":      label,
        "accuracy":   round(acc, 2),
        "size_mb":    sz,
        "sparse_mb":  round(sparse_mb, 3) if sparse_mb else None,
        "latency_ms": lat,
        "ram_mb":     ram,
    }


def print_table(results: list) -> None:
    """Pretty-print a comparison table from a list of full_metrics dicts."""
    if not results:
        return
    hdr = (f"  {'Model':<28} {'Acc':>7} {'Dense MB':>10} "
           f"{'Sparse MB':>11} {'Latency ms':>13} {'RAM MB':>9}")
    sep = "─" * (len(hdr) + 2)
    print(f"\n{sep}\n{hdr}\n{sep}")
    base = results[0]["size_mb"]
    for r in results:
        sp    = f"{r['sparse_mb']:.3f}" if r.get("sparse_mb") else "    —    "
        ratio = f"  ({base/r['size_mb']:.1f}×)" if r["size_mb"] < base * 0.99 else ""
        print(
            f"  {r['label']:<28} "
            f"{r['accuracy']:>6.2f}%  "
            f"{r['size_mb']:>9.3f}  "
            f"{sp:>10}  "
            f"{r['latency_ms']:>12.4f}  "
            f"{r['ram_mb']:>8.3f}{ratio}"
        )
    print(sep)
