"""
utils/training.py
─────────────────
Training, evaluation, and checkpointing utilities.

Improvements over original:
  - Cosine / step LR scheduler support
  - save_checkpoint / load_checkpoint helpers
  - train_and_eval returns best accuracy
"""

import os
import torch
import torch.nn as nn
import torch.optim as optim


# ── Core loops ────────────────────────────────────────────────────────────────

def train_model(
    model: nn.Module,
    train_loader,
    device: torch.device,
    epochs: int   = 5,
    lr:     float = 0.01,
    label:  str   = "Training",
) -> None:
    """Train model for `epochs` epochs. Prints loss per epoch."""
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=5e-4)

    model.train()
    for epoch in range(epochs):
        running_loss = 0.0
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            loss = criterion(model(inputs), labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        print(f"  [{label}] Epoch [{epoch+1}/{epochs}]  "
              f"Loss: {running_loss/len(train_loader):.4f}")


def evaluate(model: nn.Module, loader, device: torch.device) -> float:
    """Return top-1 accuracy (%) on the given DataLoader."""
    model.eval()
    correct = total = 0
    with torch.no_grad():
        for inputs, labels in loader:
            inputs, labels = inputs.to(device), labels.to(device)
            _, predicted = torch.max(model(inputs), 1)
            correct += (predicted == labels).sum().item()
            total   += labels.size(0)
    return 100.0 * correct / total


def train_and_eval(
    model: nn.Module,
    train_loader,
    test_loader,
    device: torch.device,
    epochs:       int   = 5,
    lr:           float = 0.01,
    weight_decay: float = 5e-4,
    scheduler:    str   = "cosine",   # "cosine" | "step" | None
    label:        str   = "",
) -> float:
    """
    Train for `epochs` epochs then evaluate.
    Prints per-epoch loss + test accuracy.
    Returns best test accuracy achieved.
    """
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(
        model.parameters(), lr=lr, momentum=0.9, weight_decay=weight_decay
    )

    if scheduler == "cosine":
        sched = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    elif scheduler == "step":
        sched = optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)
    else:
        sched = None

    tag      = f"[{label}] " if label else ""
    best_acc = 0.0

    for epoch in range(1, epochs + 1):
        # ── train ───────────────────────────────────────────────────────────
        model.train()
        running_loss = 0.0
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            loss = criterion(model(inputs), labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        # ── eval ────────────────────────────────────────────────────────────
        acc     = evaluate(model, test_loader, device)
        lr_now  = optimizer.param_groups[0]["lr"]
        print(
            f"  {tag}Epoch [{epoch:>3}/{epochs}]  "
            f"loss={running_loss/len(train_loader):.4f}  "
            f"acc={acc:.2f}%  lr={lr_now:.5f}"
        )
        if sched:
            sched.step()
        if acc > best_acc:
            best_acc = acc

    print(f"  {tag}→ Best accuracy: {best_acc:.2f}%")
    return best_acc


# ── Checkpointing ─────────────────────────────────────────────────────────────

def save_checkpoint(
    model: nn.Module,
    path:  str,
    epoch: int   = 0,
    acc:   float = 0.0,
) -> None:
    """Save model state_dict + metadata to `path`."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    torch.save({"epoch": epoch, "accuracy": acc, "state_dict": model.state_dict()}, path)
    print(f"  [ckpt] saved  → {path}  (epoch={epoch}, acc={acc:.2f}%)")


def load_checkpoint(
    model: nn.Module,
    path:  str,
    device = "cpu",
):
    """Load weights from checkpoint. Returns (model, epoch, accuracy)."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Checkpoint not found: {path}")
    ckpt  = torch.load(path, map_location=device)
    model.load_state_dict(ckpt["state_dict"])
    print(f"  [ckpt] loaded ← {path}  "
          f"(epoch={ckpt.get('epoch',0)}, acc={ckpt.get('accuracy',0):.2f}%)")
    return model, ckpt.get("epoch", 0), ckpt.get("accuracy", 0.0)
