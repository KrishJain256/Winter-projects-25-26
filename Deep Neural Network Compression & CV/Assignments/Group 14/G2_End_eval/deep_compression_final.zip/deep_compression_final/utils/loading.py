"""
utils/loading.py
────────────────
Save and load compressed models.

Preserves the original project's save_model_npz / load_model_from_npz /
load_csr_from_npz functions and adds wrappers for the new sparse CSR format.

Formats
───────
Dense .pth  (torch.save)
    Full state_dict — keeps all-zero weights.
    Used for fine-tune checkpoints; mask is intact for continued training.

KMeans .npz  (save_model_npz)
    Original project format: mask + codebook + assignments per layer.
    Used after KMeans quantisation.

Sparse CSR .npz  (save_sparse / load_sparse from compression.sparse)
    Weights stored in CSR format — actual disk-size reduction.
    Use this for deployment (no further fine-tuning needed).
"""

import numpy as np
import torch
import torch.nn as nn

from compression.linear  import modified_linear
from compression.conv2d  import modified_conv2d
from compression.sparse  import save_sparse, load_sparse
from scipy.sparse import csr_matrix


# ── Dense checkpoint ──────────────────────────────────────────────────────────

def save_dense(model: nn.Module, path: str, epoch: int = 0, acc: float = 0.0) -> None:
    """Save model state_dict as a dense .pth checkpoint."""
    import os
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    torch.save({"epoch": epoch, "accuracy": acc, "state_dict": model.state_dict()}, path)
    print(f"[loading] dense saved  → {path}")


def load_dense(model: nn.Module, path: str, device: str = "cpu"):
    """Load dense .pth checkpoint. Returns (model, epoch, accuracy)."""
    ckpt = torch.load(path, map_location=device)
    model.load_state_dict(ckpt["state_dict"])
    return model, ckpt.get("epoch", 0), ckpt.get("accuracy", 0.0)


# ── KMeans .npz (original project format) ────────────────────────────────────

def save_model_npz(model: nn.Module, savepath: str) -> None:
    """
    Save quantised layers (mask + codebook + assignments) to a .npz file.
    Original project function — preserved unchanged.
    """
    arrays = {}
    count  = 0

    for name, module in model.named_modules():
        if not hasattr(module, "assignments"):
            continue
        if not hasattr(module, "hashtable") or module.hashtable is None:
            continue

        count  += 1
        prefix  = name.replace(".", "_")

        arrays[f"{prefix}__shape"]       = np.array(module.mask.shape)
        arrays[f"{prefix}__mask"]        = module.mask.detach().cpu().numpy().astype(np.bool_)
        arrays[f"{prefix}__assignments"] = (
            module.assignments.detach().cpu().numpy().astype(np.uint8))
        arrays[f"{prefix}__codebook"]    = (
            module.hashtable.detach().cpu().numpy().astype(np.float32))

        if module.bias is not None:
            arrays[f"{prefix}__bias"] = (
                module.bias.detach().cpu().numpy().astype(np.float32))

    print(f"[save_model_npz] saved {count} layers")
    if count == 0:
        raise RuntimeError("NO COMPRESSED LAYERS FOUND — quantise the model first.")

    np.savez_compressed(savepath, **arrays)


def load_model_from_npz(model: nn.Module, npz_path: str, device: str = "cpu") -> nn.Module:
    """
    Restore a quantised model from a KMeans .npz checkpoint.
    Original project function — preserved unchanged.
    """
    raw = np.load(npz_path, allow_pickle=True)

    for name, module in model.named_modules():
        if not isinstance(module, (modified_linear, modified_conv2d)):
            continue

        prefix  = name.replace(".", "_")
        key_mask = f"{prefix}__mask"
        if key_mask not in raw:
            continue

        mask        = torch.from_numpy(raw[f"{prefix}__mask"]).to(device)
        assignments = torch.from_numpy(raw[f"{prefix}__assignments"]).to(device)
        codebook    = torch.from_numpy(raw[f"{prefix}__codebook"]).to(device)
        bias        = (
            torch.from_numpy(raw[f"{prefix}__bias"]).to(device)
            if f"{prefix}__bias" in raw else None
        )

        module.mask.copy_(mask)
        module.assignments.copy_(assignments)
        module.hashtable = nn.Parameter(codebook, requires_grad=False)

        if bias is not None and module.bias is not None:
            module.bias.data.copy_(bias)

        module.weight = None
        module.mode   = "quantize"

    return model


def load_csr_from_npz(npz_path: str) -> dict:
    """
    Load a KMeans .npz and return CSR matrices per layer.
    Original project function — preserved unchanged.
    """
    raw        = np.load(npz_path)
    csr_layers = {}
    prefixes   = set(k.split("__")[0] for k in raw.files)

    for prefix in prefixes:
        shape      = tuple(raw[f"{prefix}__shape"])
        mask       = raw[f"{prefix}__mask"]
        assignments = raw[f"{prefix}__assignments"]
        codebook   = raw[f"{prefix}__codebook"]
        bias       = raw[f"{prefix}__bias"] if f"{prefix}__bias" in raw else None

        if len(shape) == 2:
            mask_2d, assign_2d, out_shape = mask, assignments, shape
        elif len(shape) == 4:
            oc, ic, kh, kw = shape
            mask_2d   = mask.reshape(oc, -1)
            assign_2d = assignments.reshape(oc, -1)
            out_shape = (oc, ic * kh * kw)
        else:
            continue

        rows, cols = np.nonzero(mask_2d)
        if rows.size == 0:
            continue

        csr = csr_matrix(
            (assign_2d[rows, cols], (rows, cols)), shape=out_shape)

        csr_layers[prefix] = {
            "csr":        csr,
            "codebook":   codebook,
            "bias":       bias,
            "orig_shape": shape,
        }

    return csr_layers


# ── Sparse CSR .npz (new format) ──────────────────────────────────────────────

def save_compressed(model: nn.Module, path: str) -> float:
    """Save model in CSR sparse format. Returns file size in MB."""
    return save_sparse(model, path)


def load_compressed(model: nn.Module, path: str, device: str = "cpu") -> nn.Module:
    """Load model from a sparse CSR .npz file."""
    return load_sparse(model, path, device=device)
