"""
data/data_loader.py
───────────────────
CIFAR-10 and MNIST data loaders.

Bug fixed (original project):
    CIFAR10_loader was calling datasets.MNIST — corrected to datasets.CIFAR10.

Improvements over original:
    - Proper per-channel normalisation (mean/std from CIFAR-10 training set)
    - Optional data augmentation (random crop + horizontal flip)
    - Configurable batch size and num_workers
"""

from torch.utils.data import DataLoader
from torchvision import datasets, transforms

# ── CIFAR-10 stats ────────────────────────────────────────────────────────────
_CIFAR_MEAN = (0.4914, 0.4822, 0.4465)
_CIFAR_STD  = (0.2023, 0.1994, 0.2010)

# ── MNIST stats ───────────────────────────────────────────────────────────────
_MNIST_MEAN = (0.1307,)
_MNIST_STD  = (0.3081,)


def CIFAR10_loader(
    path: str        = "data",
    batch_size: int  = 128,
    augment: bool    = True,
    num_workers: int = 2,
):
    """
    Return (train_loader, test_loader) for CIFAR-10.

    BUG FIX: original code used datasets.MNIST here — corrected to CIFAR10.
    """
    train_tf = transforms.Compose([
        *([ transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip() ] if augment else []),
        transforms.ToTensor(),
        transforms.Normalize(_CIFAR_MEAN, _CIFAR_STD),
    ])
    test_tf = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(_CIFAR_MEAN, _CIFAR_STD),
    ])

    train_ds = datasets.CIFAR10(
        root=f"{path}/CIFAR10", train=True,  download=True, transform=train_tf)
    test_ds  = datasets.CIFAR10(
        root=f"{path}/CIFAR10", train=False, download=True, transform=test_tf)

    train_loader = DataLoader(train_ds, batch_size=batch_size,
                              shuffle=True,  num_workers=num_workers, pin_memory=True)
    test_loader  = DataLoader(test_ds,  batch_size=batch_size,
                              shuffle=False, num_workers=num_workers, pin_memory=True)

    print(f"[data] CIFAR-10  train={len(train_ds):,}  test={len(test_ds):,}  "
          f"batch={batch_size}  augment={augment}")
    return train_loader, test_loader


def MNIST_loader(
    path: str        = "data",
    batch_size: int  = 128,
    num_workers: int = 2,
):
    """Return (train_loader, test_loader) for MNIST."""
    tf = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(_MNIST_MEAN, _MNIST_STD),
    ])
    train_ds = datasets.MNIST(
        root=f"{path}/MNIST", train=True,  download=True, transform=tf)
    test_ds  = datasets.MNIST(
        root=f"{path}/MNIST", train=False, download=True, transform=tf)

    train_loader = DataLoader(train_ds, batch_size=batch_size,
                              shuffle=True,  num_workers=num_workers, pin_memory=True)
    test_loader  = DataLoader(test_ds,  batch_size=batch_size,
                              shuffle=False, num_workers=num_workers, pin_memory=True)
    return train_loader, test_loader
